package lap_1;
import javax.swing.JOptionPane;

public class helloworld {
    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}